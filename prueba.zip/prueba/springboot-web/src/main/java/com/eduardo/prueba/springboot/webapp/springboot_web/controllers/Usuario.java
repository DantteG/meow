package com.eduardo.prueba.springboot.webapp.springboot_web.controllers;

public class Usuario {

}
